#!/bin/bash

sudo python lab3.py
